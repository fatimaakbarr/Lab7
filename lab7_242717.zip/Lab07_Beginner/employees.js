// Task 2: Read JSON, show employees, add one, and save.
const fs = require("fs"); // Built-in file system module
const employees = JSON.parse(fs.readFileSync("employees.json", "utf8"));
console.log("Employees before adding:", employees);
// Find the next unused ID; avoid adding the same example again.
if (!employees.some(employee => employee.name === "Hassan")) {
  const newId = Math.max(0, ...employees.map(employee => employee.id)) + 1;
  employees.push({ id: newId, name: "Hassan", department: "Marketing" });
  fs.writeFileSync("employees.json", JSON.stringify(employees, null, 2));
  console.log("One employee added and saved.");
} else {
  console.log("Hassan already exists; no duplicate added.");
}
console.log("Employees after:", employees);
