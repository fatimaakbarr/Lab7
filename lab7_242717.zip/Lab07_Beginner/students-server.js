// Tasks 3 and 4: Student API with department filter and validation.
const express = require("express");
const fs = require("fs");
const app = express();
app.use(express.json()); // Converts JSON request body into req.body.
let students = JSON.parse(fs.readFileSync("students.json", "utf8"));
function validStudent(body) {
  return body && typeof body.name === "string" && body.name.trim() !== "" &&
    typeof body.department === "string" && body.department.trim() !== "";
}
function save() {
  fs.writeFileSync("students.json", JSON.stringify(students, null, 2));
}
app.get("/students", (req, res) => res.json(students));
// IMPORTANT: Department route goes before the ID route.
app.get("/students/department/:department", (req, res) => {
  const result = students.filter(s => s.department.toLowerCase() === req.params.department.toLowerCase());
  res.json(result);
});
app.get("/students/:id", (req, res) => {
  const student = students.find(s => s.id === Number(req.params.id));
  if (!student) return res.status(404).json({ message: "Student not found" });
  res.json(student);
});
app.post("/students", (req, res) => {
  if (!validStudent(req.body)) return res.status(400).json({ message: "Name and department are required" });
  const id = Math.max(0, ...students.map(s => s.id)) + 1;
  const student = { id, name: req.body.name.trim(), department: req.body.department.trim() };
  students.push(student);
  save();
  res.status(201).json(student);
});
app.put("/students/:id", (req, res) => {
  const student = students.find(s => s.id === Number(req.params.id));
  if (!student) return res.status(404).json({ message: "Student not found" });
  if (!validStudent(req.body)) return res.status(400).json({ message: "Name and department are required" });
  student.name = req.body.name.trim();
  student.department = req.body.department.trim();
  save();
  res.json(student);
});
app.delete("/students/:id", (req, res) => {
  const index = students.findIndex(s => s.id === Number(req.params.id));
  if (index === -1) return res.status(404).json({ message: "Student not found" });
  const deleted = students.splice(index, 1)[0];
  save();
  res.json({ message: "Student deleted", student: deleted });
});
app.listen(3000, () => console.log("Student API: http://localhost:3000"));
