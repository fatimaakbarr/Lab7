// Task 1: Each function performs one calculation.
function add(a, b) { return a + b; }
function subtract(a, b) { return a - b; }
function multiply(a, b) { return a * b; }
function divide(a, b) {
  if (b === 0) { throw new Error("Cannot divide by zero"); }
  return a / b;
}
// Allow app.js to use these functions.
module.exports = { add, subtract, multiply, divide };
