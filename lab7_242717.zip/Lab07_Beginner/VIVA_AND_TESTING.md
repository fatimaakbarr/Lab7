# LAB 07 — Simple viva guide and testing

## What I made (say this to your teacher)
"In this lab, I used Node.js to run JavaScript. I made my own calculator module,
read and updated an employee JSON file, created a student API with department filtering
and input validation, and built a Book Management API using Express. I tested API
requests using GET, POST, PUT, and DELETE. The changes are saved to JSON files."

## Run the project
1. Open this folder in VS Code and open Terminal.
2. Run `npm install` once (requires internet to fetch Express).
3. Run `node app.js` for Task 1. Expected: 15, 5, 50, 2, followed by divide-by-zero error.
4. Run `node employees.js` for Task 2. It prints 5 employees and adds Hassan once.
5. Run `node students-server.js` for Tasks 3–4. Keep terminal open while using Postman.
6. Stop the Student API with Ctrl+C before starting `node books-server.js`, because both use port 3000.
7. Run `node books-server.js` for the Book Management assignment. Keep terminal open.

## Book Management API: Postman instructions
In Postman select the method, paste the URL and click Send. For POST/PUT, use **Body > raw > JSON**.

| Test | Method | URL | Expected status |
|---|---|---|---|
| All books | GET | http://localhost:3000/books | 200 |
| Book 1 | GET | http://localhost:3000/books/1 | 200 |
| Missing book | GET | http://localhost:3000/books/999 | 404 |
| Add book | POST | http://localhost:3000/books | 201 |
| Invalid add | POST | http://localhost:3000/books | 400 |
| Update added book | PUT | http://localhost:3000/books/4 | 200 |
| Delete added book | DELETE | http://localhost:3000/books/4 | 200 |

POST request body:
```json
{"title":"Database Basics","author":"Fatima","price":1000}
```
PUT request body (use the actual new ID returned by POST):
```json
{"title":"Advanced Database Basics","author":"Fatima","price":1300}
```
Invalid POST example (400):
```json
{"title":"","author":"Fatima","price":1000}
```
**Screenshots required by teacher:** capture Postman method, URL, Body (POST/PUT), response and status for GET all, GET one, POST, PUT, DELETE; optionally 400 and 404. Screenshots are NOT included because actual Postman has to be run on your device.

## Student API tests (run students-server.js instead)
- GET `http://localhost:3000/students/department/BSCS` → Ali and Sara.
- GET `http://localhost:3000/students/department/BSIT` → Ahmed.
- POST `http://localhost:3000/students` body `{ "name":"", "department":"BSCS" }` → 400.
- POST body `{ "department":"BSCS" }` → 400 (missing name).
- PUT `http://localhost:3000/students/1` body `{ "name":"Ali" }` → 400 (missing department).
- POST body `{ "name":"Hadia", "department":"BSIT" }` → 201.

## Line-by-line ideas for viva (the key lines)
- `require("express")`: loads Express so we can create routes easily.
- `require("fs")`: loads Node's built-in file handling module.
- `express()`: creates our API application.
- `app.use(express.json())`: lets Express read JSON sent by Postman as `req.body`.
- `readFileSync(...)`: reads records from a JSON file.
- `JSON.parse(...)`: converts JSON text into a JavaScript array/object.
- `app.get(...)`: handles an HTTP request to view data.
- `app.post(...)`: handles a request to create data.
- `app.put(...)`: handles a request to update data.
- `app.delete(...)`: handles a request to remove data.
- `req.params.id`: reads the ID written in the URL.
- `req.body`: reads the data supplied by Postman.
- `find(...)`: finds one matching record; `findIndex(...)`: finds its position.
- `push(...)`: adds to an array; `splice(...)`: removes from an array.
- `res.status(404).json(...)`: sends an error if that record does not exist.
- `JSON.stringify(books, null, 2)`: converts array back to pretty JSON text.
- `writeFileSync(...)`: writes the updated records into the file.
- `app.listen(3000, ...)`: starts the server at port 3000.

## Common viva questions with very short answers
**Q: What is Node.js?** A: JavaScript runtime that works outside the browser.

**Q: What is npm?** A: A package manager used to install libraries like Express.

**Q: What is a module?** A: A reusable file; `module.exports` exports and `require` imports it.

**Q: What is Express?** A: A framework for building web servers and APIs with Node.js.

**Q: What is an API?** A: A way for applications to send requests and receive responses.

**Q: What is REST?** A: An API design style using URLs and HTTP methods for resources.

**Q: What is CRUD?** A: Create, Read, Update, Delete.

**Q: What is JSON?** A: A text format for exchanging and storing structured data.

**Q: What is Postman?** A: A tool for sending test HTTP requests to an API.

**Q: Difference between POST and PUT?** A: POST creates a new record; PUT updates/replaces an existing one.

**Q: Why validate input?** A: To reject missing or incorrect values before saving.

**Q: What do 200, 201, 400, 404 mean?** A: Success; created; bad input; not found.

**Q: Why do we save to a JSON file?** A: So updated records remain after the server restarts.

**Q: What is `localhost:3000`?** A: The server running on my own computer, on port 3000.

**Q: Why do we check divide by zero?** A: Division by zero is invalid for this calculator and should show a clear error.

**Q: What is a limitation here?** A: Synchronous files are fine for a lab, but a production app should use a database and stronger error handling.
