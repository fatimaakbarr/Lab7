// LAB 07: BOOK MANAGEMENT REST API (MAIN ASSIGNMENT)
// Viva: This backend lets Postman create, read, update and delete books.
// Run: npm.cmd install (first time), then node books-server.js.
// Test: http://localhost:3000/books
// GET = read | POST = create | PUT = update | DELETE = remove.

// Import Express to create HTTP routes.
const express = require("express");
// Import Node.js File System to read/write the JSON file.
const fs = require("fs");
// Create our Express server application.
const app = express();
app.use(express.json()); // Read JSON data sent from Postman.
// Read books.json as text, then JSON.parse converts it into an array.
let books = JSON.parse(fs.readFileSync("books.json", "utf8"));
// Save after changes so data survives a restart (extra credit).
function saveBooks() {
  fs.writeFileSync("books.json", JSON.stringify(books, null, 2));
}
// True only when all required fields are correct.
// The title and author must be non-empty strings; price must be >= 0.
// For an invalid request, POST/PUT return HTTP 400 (Bad Request).
function validBook(body) {
  return body && typeof body.title === "string" && body.title.trim() !== "" &&
    typeof body.author === "string" && body.author.trim() !== "" &&
    typeof body.price === "number" && Number.isFinite(body.price) && body.price >= 0;
}
// GET all books.
app.get("/books", (req, res) => {
  res.status(200).json(books);
});
// GET a single book by its ID.
app.get("/books/:id", (req, res) => {
  const book = books.find(b => b.id === Number(req.params.id));
  if (!book) return res.status(404).json({ message: "Book not found" });
  res.status(200).json(book);
});
// POST: Add one book.
app.post("/books", (req, res) => {
  if (!validBook(req.body)) return res.status(400).json({ message: "Valid title, author and non-negative numeric price are required" });
  // Make a new ID larger than any existing book ID.
  const id = Math.max(0, ...books.map(b => b.id)) + 1;
  const book = { id, title: req.body.title.trim(), author: req.body.author.trim(), price: req.body.price };
  // Add the newly created book to the array.
  books.push(book);
  saveBooks();
  res.status(201).json(book);
});
// PUT: Replace the editable fields of an existing book.
app.put("/books/:id", (req, res) => {
  const book = books.find(b => b.id === Number(req.params.id));
  if (!book) return res.status(404).json({ message: "Book not found" });
  if (!validBook(req.body)) return res.status(400).json({ message: "Valid title, author and non-negative numeric price are required" });
  book.title = req.body.title.trim();
  book.author = req.body.author.trim();
  book.price = req.body.price;
  saveBooks();
  res.status(200).json(book);
});
// DELETE: Remove a book.
app.delete("/books/:id", (req, res) => {
  const index = books.findIndex(b => b.id === Number(req.params.id));
  if (index === -1) return res.status(404).json({ message: "Book not found" });
  // splice removes the matching book; [0] gets the deleted book.
  const deleted = books.splice(index, 1)[0];
  saveBooks();
  res.status(200).json({ message: "Book deleted", book: deleted });
});
// Start the API locally at port 3000. Keep this terminal open during Postman tests.
app.listen(3000, () => console.log("Book API running at http://localhost:3000"));
